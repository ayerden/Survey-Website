# General Use Guide - Advisor
General usage guide for the VGER online readiness system for use by SUNY Potsdam Advisors. 

### Selecting students
![Students](screenshots/students_screen.png)
- Simply click on your name from the navigation bar and you will be taken to a screen showing all of your students.